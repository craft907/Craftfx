
import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, FlatList, TouchableOpacity, Image, StyleSheet, Modal } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation, useFocusEffect } from '@react-navigation/native';

const PAGE_SIZE = 50;

export default function MainScreen() {
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState('');
  const [filtered, setFiltered] = useState([]);
  const [modalItem, setModalItem] = useState(null);
  const navigation = useNavigation();

  useEffect(() => {
    (async () => {
      const raw = await AsyncStorage.getItem('craftfx-items');
      const data = raw ? JSON.parse(raw) : [];
      setItems(data);
    })();
  }, []);

  useEffect(() => {
    const q = search.toLowerCase();
    setFiltered(
      items.filter(i => 
        (i.name + i.itemId + i.iconName).toLowerCase().includes(q)
      ).slice(0, PAGE_SIZE)
    );
  }, [search, items]);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Craft FX</Text>
        <TouchableOpacity onPress={() => navigation.navigate('Admin')}>
          <Text style={styles.adminLink}>Admin</Text>
        </TouchableOpacity>
      </View>

      <TextInput
        placeholder="Search"
        placeholderTextColor="#888"
        style={styles.search}
        value={search}
        onChangeText={setSearch}
      />

      <FlatList
        data={filtered}
        numColumns={4}
        keyExtractor={(_, idx) => idx.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.iconWrap} onPress={() => setModalItem(item)}>
            <Image source={{ uri: item.icon }} style={styles.icon} />
          </TouchableOpacity>
        )}
      />

      <Modal visible={!!modalItem} transparent animationType="fade">
        <TouchableOpacity style={styles.modalBack} onPress={() => setModalItem(null)}>
          <View style={styles.modalCard}>
            {modalItem && (
              <>
                <Image source={{ uri: modalItem.icon }} style={styles.modalImg}/>
                <Text style={styles.modalTxt}>Name: {modalItem.name}</Text>
                <Text style={styles.modalTxt}>Item: {modalItem.itemId}</Text>
                <Text style={styles.modalTxt}>Icon: {modalItem.iconName}</Text>
              </>
            )}
          </View>
        </TouchableOpacity>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000', paddingTop: 50, paddingHorizontal: 10 },
  header: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 },
  title: { color: '#fff', fontSize: 24, fontWeight: 'bold' },
  adminLink: { color: '#0af' },
  search: { backgroundColor: '#111', color: '#fff', padding: 8, borderRadius: 8, marginBottom: 10 },
  iconWrap: { flex: 1/4, padding: 4 },
  icon: { width: '100%', aspectRatio: 1, backgroundColor: '#222', borderRadius: 8 },
  modalBack: { flex:1, backgroundColor:'rgba(0,0,0,0.8)', justifyContent:'center', alignItems:'center' },
  modalCard: { backgroundColor:'#111', padding:20, borderRadius:12, alignItems:'center', width:250 },
  modalImg:{ width:120, height:120, marginBottom:10 },
  modalTxt:{ color:'#fff' }
});
