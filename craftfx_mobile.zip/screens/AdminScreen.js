
import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, FlatList, TouchableOpacity, Image, StyleSheet, Alert, ScrollView } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as ImagePicker from 'expo-image-picker';
import { useNavigation } from '@react-navigation/native';

const password = 'craft22663';

export default function AdminScreen() {
  const navigation = useNavigation();
  const [auth, setAuth] = useState(false);
  const [pw, setPw] = useState('');
  const [items, setItems] = useState([]);

  useEffect(() => {
    (async () => {
      const raw = await AsyncStorage.getItem('craftfx-items');
      setItems(raw ? JSON.parse(raw) : []);
    })();
  }, [auth]);

  const saveItems = async (newItems) => {
    setItems(newItems);
    await AsyncStorage.setItem('craftfx-items', JSON.stringify(newItems));
  };

  const pickImage = async (cb) => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.5,
      base64: true
    });
    if (!result.canceled) {
      cb(`data:image/jpeg;base64,${result.assets[0].base64}`);
    }
  };

  if (!auth) {
    return (
      <View style={styles.center}>
        <TextInput
          placeholder="Password"
          placeholderTextColor="#666"
          secureTextEntry
          style={styles.pw}
          value={pw}
          onChangeText={setPw}
          onSubmitEditing={() => {
            if (pw === password) setAuth(true);
            else Alert.alert('Wrong password');
          }}
        />
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={{ color:'#0af', marginTop:10 }}>Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.admin}>
      <Text style={styles.title}>Admin Panel</Text>
      <TouchableOpacity style={styles.addBtn} onPress={() => saveItems([{ name:'New', itemId:Date.now(), iconName:'', icon:'', category:'', rarity:'' }, ...items])}>
        <Text style={{color:'#fff'}}>+ Add Item</Text>
      </TouchableOpacity>

      {items.map((item, idx) => (
        <View key={idx} style={styles.itemRow}>
          <TouchableOpacity onPress={() => pickImage(uri => {
            const next = [...items];
            next[idx].icon = uri;
            saveItems(next);
          })}>
            {item.icon ? (
              <Image source={{ uri:item.icon }} style={styles.rowImg}/>
            ) : (
              <View style={[styles.rowImg,{backgroundColor:'#333', justifyContent:'center', alignItems:'center'}]}>
                <Text style={{color:'#666'}}>Pick</Text>
              </View>
            )}
          </TouchableOpacity>
          <View style={{ flex:1, marginLeft:6 }}>
            {['name','itemId','iconName','category','rarity'].map(key => (
              <TextInput
                key={key}
                placeholder={key}
                placeholderTextColor="#666"
                style={styles.input}
                value={item[key].toString()}
                onChangeText={val => {
                  const next=[...items]; next[idx][key]=val; saveItems(next);
                }}
              />
            ))}
          </View>
          <TouchableOpacity onPress={() => {
            const next = items.filter((_,i)=>i!==idx);
            saveItems(next);
          }}>
            <Text style={{color:'#f55'}}>Del</Text>
          </TouchableOpacity>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  center:{ flex:1, justifyContent:'center', alignItems:'center', backgroundColor:'#000' },
  pw:{ backgroundColor:'#111', color:'#fff', padding:10, borderRadius:8, width:200 },
  admin:{ backgroundColor:'#000', padding:20 },
  title:{ color:'#fff', fontSize:24, marginBottom:10 },
  addBtn:{ backgroundColor:'#0af', padding:10, borderRadius:8, alignSelf:'flex-start', marginBottom:10 },
  itemRow:{ flexDirection:'row', marginBottom:15, alignItems:'center' },
  rowImg:{ width:60, height:60, borderRadius:6 },
  input:{ backgroundColor:'#111', color:'#fff', padding:6, marginBottom:4, borderRadius:6 }
});
